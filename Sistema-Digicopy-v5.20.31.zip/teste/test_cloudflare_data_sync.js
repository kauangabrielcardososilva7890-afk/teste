const fs=require('fs');
function ok(name,cond){if(!cond){console.error('  ✘ '+name);process.exit(1);}console.log('  ✔ '+name);}
const code=fs.readFileSync('cloudflare_data_sync_patch.js','utf8');
const html=fs.readFileSync('index.html','utf8');
const window={DIGICOPY_CLOUD:{token:()=>''}};
new Function('window','localStorage','document',code)(window,{getItem:()=>null,setItem:()=>{},removeItem:()=>{}},undefined);
const S=window.DIGICOPY_CLOUD_SYNC;
console.log('== CLOUDFLARE DATA SYNC ==');
ok('motor exportado',!!S&&typeof S.tick==='function');
ok('sincroniza todas as entidades principais',S.definitions.clientes==='array'&&S.definitions.vendas==='array'&&S.definitions.config==='root');
ok('limpa metadados antigos',!('_rt' in S.clean({id:'1',_rt:'x'})));
ok('hash é estável com ordem diferente',S.hash({b:2,a:1})===S.hash({a:1,b:2}));
ok('possui fila local durável',/digicopy_cf_sync_outbox_v1/.test(code));
ok('sempre puxa antes de escanear e enviar',/await pullAll\(\);[\s\S]{0,180}scanLocal\(\)/.test(code));
ok('bloqueia exclusão em massa inesperada',/missing\.length>=10/.test(code)&&/blockedDeletes/.test(code));
ok('usa cursor incremental',/\/v1\/changes\?cursor=/.test(code));
ok('usa backoff e não setInterval',/Math\.pow/.test(code)&&!/setInterval\s*\(/.test(code));
ok('script carregado depois do painel',html.indexOf('cloudflare_data_sync_patch.js')>html.indexOf('cloudflare_sync_patch.js'));
console.log('\nRESULTADO: motor Cloudflare passou!');
